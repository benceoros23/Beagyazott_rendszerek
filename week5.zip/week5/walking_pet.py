from sense_hat import SenseHat
import time
import math

sense = SenseHat()

P = (255, 0, 255)      # pink (fülek, farok)
G = (0, 102, 102)      # zöldeskék (test)
Y = (255, 255, 0)      # sárga (arc)
W = (255, 255, 255)    # fehér (szem)
B = (0, 0, 0)          # háttér

cat1 = [
    P,B,B,B,B,B,B,B,
    B,P,B,B,P,P,B,B,
    B,P,G,G,G,Y,Y,G,
    B,G,G,G,Y,Y,Y,G,
    G,G,G,Y,W,Y,G,B,
    G,B,G,G,G,G,B,B,
    G,B,G,B,G,B,B,B,
    B,B,B,B,B,B,B,B
]

cat2 = [
    B,P,B,B,B,B,B,B,
    B,P,B,B,P,P,B,B,
    B,P,G,G,G,Y,Y,G,
    B,G,G,G,Y,Y,Y,G,
    G,G,G,Y,W,Y,G,B,
    B,G,G,G,G,G,B,B,
    G,B,G,B,G,B,B,B,
    B,B,B,B,B,B,B,B
]

def walk_pet():
    for _ in range(5):
        sense.set_pixels(cat1)
        time.sleep(0.5)
        sense.set_pixels(cat2)
        time.sleep(0.5)
    sense.clear()

def get_force():
    acc = sense.get_accelerometer_raw()
    x, y, z = acc['x'], acc['y'], acc['z']
    return math.sqrt(x*x + y*y + z*z)

THRESHOLD = 1.5

print("Walking cat program running...")
print("Move or shake the Sense HAT to trigger animation!")

while True:
    F = get_force()
    if F > THRESHOLD:
        walk_pet()
    time.sleep(0.1)
