from sense_hat import SenseHat
import time

sense = SenseHat()
ALTITUDE = 125

def sea_level_pressure(P, T, h=ALTITUDE):
    return P * (1 - (0.0065 * h) / (T + 0.0065 * h + 273.15)) ** (-5.257)

def zambretti_forecast(P0, tendency):
    if tendency == "falling" and 985 <= P0 <= 1050:
        Z = round(127 - 0.12 * P0)
        table = {
            1: "Settled Fine", 2: "Fine Weather", 3: "Fine, Becoming Less Settled",
            4: "Fairly Fine, Showery Later", 5: "Showery, Becoming More Unsettled",
            6: "Unsettled, Rain Later", 7: "Rain at Times, Worse Later",
            8: "Rain at Times, Becoming Very Unsettled", 9: "Very Unsettled, Rain"
        }
        return table.get(Z, "Out of range (falling)")
    elif tendency == "steady" and 960 <= P0 <= 1033:
        Z = round(144 - 0.13 * P0)
        table = {
            10: "Settled Fine", 11: "Fine Weather", 12: "Fine, Possibly Showers",
            13: "Fairly Fine, Showers Likely", 14: "Showery, Bright Intervals",
            15: "Changeable, Some Rain", 16: "Unsettled, Rain at Times",
            17: "Rain at Frequent Intervals", 18: "Very Unsettled, Rain"
        }
        return table.get(Z, "Out of range (steady)")
    elif tendency == "rising" and 947 <= P0 <= 1030:
        Z = round(185 - 0.16 * P0)
        table = {
            20: "Settled Fine", 21: "Fine Weather", 22: "Becoming Fine",
            23: "Fairly Fine, Improving", 24: "Fairly Fine, Possibly Showers Early",
            25: "Showery Early, Improving", 26: "Changeable, Mending",
            27: "Rather Unsettled, Clearing Later", 28: "Unsettled, Probably Improving",
            29: "Unsettled, Short Fine Intervals", 30: "Very Unsettled, Finer at Times",
            31: "Stormy, Possibly Improving", 32: "Stormy, Much Rain"
        }
        return table.get(Z, "Out of range (rising)")
    else:
        return "Pressure out of valid range or invalid tendency."

print("Starting weather forecast using simplified Zambretti’s algorithm...")
P_initial = sense.get_pressure()
time.sleep(2)
P_new = sense.get_pressure()
T = sense.get_temperature()
P0 = sea_level_pressure(P_new, T)
delta_P = P_new - P_initial
if delta_P > 1.6:
    tendency = "rising"
elif delta_P < -1.6:
    tendency = "falling"
else:
    tendency = "steady"
print(f"Measured pressure: {P_new:.2f} hPa")
print(f"Temperature: {T:.2f} °C")
print(f"Sea-level pressure (P0): {P0:.2f} hPa")
print(f"Pressure tendency: {tendency}")
forecast = zambretti_forecast(P0, tendency)
print(f"Forecast: {forecast}")
