from sense_hat import SenseHat
import math

sense = SenseHat()
P0 = 1013.25

P = sense.get_pressure()
h = 44331 * (1 - (P / P0) ** (1 / 5.2558))

print(f"Measured pressure: {P:.2f} hPa")
print(f"Predicted altitude: {h:.2f} meters")
