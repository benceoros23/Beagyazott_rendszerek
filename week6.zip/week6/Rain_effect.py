from sense_hat import SenseHat
import time
import random

sense = SenseHat()

b = (0, 0, 255)
n = (0, 0, 0)

matrix = [[n for _ in range(8)] for _ in range(8)]

def draw_matrix():
    flat = [pixel for row in matrix for pixel in row]
    sense.set_pixels(flat)

def rain_step():
    for i in range(7, 0, -1):
        matrix[i] = matrix[i-1][:]
    new_drop = [n]*8
    new_drop[random.randint(0,7)] = b
    matrix[0] = new_drop
    draw_matrix()

def main():
    while True:
        rain_step()
        time.sleep(0.5)

main()
