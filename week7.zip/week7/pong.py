from sense_hat import SenseHat
import random
from time import sleep

sense = SenseHat()
speed = 0.3
bat = [7, 4]
score = 0
up_down = -1

w = (0, 0, 0)
r = (255, 0, 0)
b = (0, 0, 255)

game_space = [w] * 64
game_space[8 * bat[0] + bat[1]] = b
game_space[8 * bat[0] + bat[1] - 1] = b

def update_space(x, y, colour):
    pos = 8 * x + y
    game_space[pos] = colour
    sense.set_pixels(game_space)

def left(event):
    if event.action == 'pressed':
        if bat[1] - 2 >= 0:
            update_space(bat[0], bat[1], w)
            update_space(bat[0], bat[1] - 1, w)
            bat[1] -= 1
            update_space(bat[0], bat[1], b)
            update_space(bat[0], bat[1] - 1, b)

def right(event):
    if event.action == 'pressed':
        if bat[1] + 1 < 8:
            update_space(bat[0], bat[1], w)
            update_space(bat[0], bat[1] - 1, w)
            bat[1] += 1
            update_space(bat[0], bat[1], b)
            update_space(bat[0], bat[1] - 1, b)

sense.stick.direction_left = left
sense.stick.direction_right = right

sense.clear()
sense.set_pixels(game_space)
game_alive = True

x = 0
y = random.randint(0, 7)
d = random.choice([-1, 1])
update_space(x, y, r)

while game_alive:
    sleep(speed)
    update_space(x, y, w)

    if y == 7 and d == 1:
        d = -1
    elif y == 0 and d == -1:
        d = 1

    if x == 0:
        up_down = 1
    elif x == 7:
        if y == bat[1] or y == bat[1] - 1:
            up_down = -1
            score += 1
        else:
            game_alive = False
            break

    x += up_down
    y += d
    update_space(x, y, r)

sense.clear()
sense.show_message('Game over!', scroll_speed=0.05, back_colour=w)
sense.show_message('Score: ' + str(score), scroll_speed=0.05, back_colour=w)


