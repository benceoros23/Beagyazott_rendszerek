from sense_hat import SenseHat
from time import sleep
import random

sense = SenseHat()
sense.clear()

s = (0, 255, 0)
f = (255, 0, 0)
e = (0, 0, 0)

snake = [(4, 4)]
direction = (0, -1)
food = (random.randint(0, 7), random.randint(0, 7))
while food in snake:
    food = (random.randint(0, 7), random.randint(0, 7))

def draw():
    pixels = [e] * 64
    for x, y in snake:
        pixels[y * 8 + x] = s
    fx, fy = food
    pixels[fy * 8 + fx] = f
    sense.set_pixels(pixels)

def move():
    head_x, head_y = snake[0]
    dx, dy = direction
    new_head = (head_x + dx, head_y + dy)
    if (new_head in snake or not (0 <= new_head[0] <= 7 and 0 <= new_head[1] <= 7)):
        return False
    snake.insert(0, new_head)
    if new_head == food:
        place_food()
    else:
        snake.pop()
    return True

def place_food():
    global food
    while True:
        food = (random.randint(0, 7), random.randint(0, 7))
        if food not in snake:
            break

def up(event):
    global direction
    if event.action == 'pressed' and direction != (0, 1):
        direction = (0, -1)

def down(event):
    global direction
    if event.action == 'pressed' and direction != (0, -1):
        direction = (0, 1)

def left(event):
    global direction
    if event.action == 'pressed' and direction != (1, 0):
        direction = (-1, 0)

def right(event):
    global direction
    if event.action == 'pressed' and direction != (-1, 0):
        direction = (1, 0)

sense.stick.direction_up = up
sense.stick.direction_down = down
sense.stick.direction_left = left
sense.stick.direction_right = right

draw()
game_alive = True

while game_alive:
    sleep(0.7)
    game_alive = move()
    draw()




sense.show_message("Game Over", text_colour=(255, 255, 255))
