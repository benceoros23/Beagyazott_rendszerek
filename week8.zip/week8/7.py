from picamera2 import Picamera2, Preview
import time
import cv2

picamera = Picamera2()
config = picamera.create_still_configuration(main={"size": (1280, 720)})
picamera.configure(config)
picamera.start_preview(Preview.QTGL)
picamera.start()
time.sleep(2)
picamera.capture_file("photo.jpg")
picamera.stop_preview()
picamera.close()

image = cv2.imread("photo.jpg")
cv2.imshow("Captured", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
