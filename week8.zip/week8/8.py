from imutils.video import VideoStream
import imutils
import datetime
import time
import cv2

vs = VideoStream(usePiCamera=True).start()
time.sleep(2)

while True:
    frame = vs.read()
    if frame is None:
        continue
    frame = imutils.resize(frame, width=400)
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(frame, ts, (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
    cv2.imshow("Video Stream", frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break

cv2.destroyAllWindows()
vs.stop()
